<?php

namespace PurpleCommerce\CustomPDFButton\Controller\Adminhtml\Order\Invoice;

class Index extends \Magento\Backend\App\Action
{
    /**
     * Hello test controller page.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
       echo 'worked';
    }
 
    
}