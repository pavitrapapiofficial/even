<?php
namespace PurpleCommerce\CustomPDFButton\Plugin\Block\Adminhtml\Order\Invoice;

class View {

public function beforeSetLayout(\Magento\Sales\Block\Adminhtml\Order\Invoice\View $view)
{
    $message ='Are you sure you want to do this?';
    $invoId = time().'#'.$view->getInvoice()->getId();
    $url = '/maltwin_design/pdfinvoice?id=' . base64_encode($invoId);
    

    $view->addButton(
        'order_myaction',
        [
            'label' => __('GST Invoice'),
            'class' => 'myclass',
            'onclick' => "setLocation('$url')"
        ]
    );


}
}
